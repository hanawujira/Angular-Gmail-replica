export class MenuModel {
    public icon: string | undefined;
    public text: string | undefined;
    public count: number | undefined;
}